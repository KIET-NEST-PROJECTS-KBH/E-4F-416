# Virtual-Mouse-Using-Hand-Gesture
Virtual Mouse is a Python Project build with the help of Opencv ,numpy , pynput and wxpython Libraries. 

THis is a Virtual mouse using hand gesture made in python using opencv.

Feel Free to ask if any Error Occurs.
